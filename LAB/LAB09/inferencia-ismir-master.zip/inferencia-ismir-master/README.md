# Conflito em Jukeboxes Sociais

Dados do experimento [nesse artigo](http://ismir2015.uma.es/articles/212_Paper.pdf). 
